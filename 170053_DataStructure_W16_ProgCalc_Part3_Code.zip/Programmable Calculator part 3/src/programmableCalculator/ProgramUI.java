package programmableCalculator;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.Stack;
import java.util.StringTokenizer;

import dictionary.Dictionary;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import lexer.Lexer;
import lexer.Token;
import lexer.Token.Kind;

/**
 * <p>
 * Title: ProgramUI Class.
 * </p>
 * 
 * <p>
 * Description: The Java/FX-based user interface for the calculator. The class
 * works with String objects and passes work to other classes to deal with all
 * other aspects of the computation.
 * </p>
 * 
 * <p>
 * Copyright: Lynn Robert Carter � 2017
 * </p>
 * 
 * @author Yash
 * 
 * @author Yash
 * 
 * @version 1.00 Class which runs the program having different type of mathematical operations 
 */

public class ProgramUI  {
	
	private final double BUTTON_WIDTH = 32;
	
	private Button button_run = new Button ("Run");
	private Button load = new Button("Load");
	private Button button_edit = new Button("Edit");
	private Button button_list = new Button("List All Programs");
	private Button button_Create = new Button ("Create");
	private Button button_delete = new Button ("Delete");
	private Button button_save = new Button ("Save");
	private Button button_debug = new Button ("Debug");
	private Label select = new Label("Select the File");
	private Label enter = new Label("Enter file Name");
	private Label programIn = new Label("Write Program");
	private Label programOut = new Label("Program Output");
	private TextArea area1 = new TextArea();
	private TextField text1 = new TextField();
	private static  TextArea area2 = new TextArea();
	private static String theExpression = "";
	private static Scanner theReader = new Scanner (theExpression);
	private static Lexer lexer;
	private static Token current;
	private static Token next;
	ObservableList<String> list = FXCollections.observableArrayList();
	private ComboBox<String> combo1 = new ComboBox<String>(list);
	File theDirectory = new File("Repository");
	
	File[] name = theDirectory.listFiles();
	
	Dictionary<String> dict = new Dictionary<String>();
	
	// The following are the stacks that are used to transform the parse output into a tree
	private static Stack<ExprNode> exprStack = new Stack<>();
	private static Stack<Token> opStack = new Stack<>();
	
	
	public ProgramUI(Stage resultStage) throws IOException {
		Pane theRoot = new Pane();
		
		
		setupButtonUI(button_run, "Symbol", 15, BUTTON_WIDTH, Pos.BASELINE_LEFT,450,30);
		button_run.setOnAction((event) -> {try {
			Run();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}});
		
		
		
		setupButtonUI(button_edit, "Symbol", 15, BUTTON_WIDTH, Pos.BASELINE_LEFT,300,400);
		button_edit.setOnAction((event) -> {
			area1.setEditable(true);
			button_save.setDisable(false);
		});
		
		setupComboBoxUI(combo1, 150, 10, 30, 30);
		combo1.setOnMouseClicked((event) -> {
			
			combo1.getItems().clear();
			if(combo1.getSelectionModel()== null) {
				load.setDisable(true);
			}
			else {
				load.setDisable(false);
			}
			ShowFile();
			});
		
		setupLabelUI(select,30,15);
		setupLabelUI(enter,30,85);
		setupLabelUI(programIn,20,135);
		setupLabelUI(programOut,340,135);
		
		
		setupButtonUI(load, "Symbol", 15, BUTTON_WIDTH, Pos.BASELINE_LEFT,200,30);
		load.setOnAction((event) -> {	
		area1.setDisable(false);
		button_save.setDisable(true);
		button_Create.setDisable(true);
		 combo1.setDisable(true);
		 try {
			dict.loadDictionary(combo1, area1);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		});
		
		setupButtonUI(button_Create, "Symbol", 15, BUTTON_WIDTH, Pos.BASELINE_LEFT,300,100);
		button_Create.setOnAction((event) -> {
			area1.setDisable(false);
			dict.create(text1, area1);
		});
		
		setupButtonUI(button_delete, "Symbol", 15, BUTTON_WIDTH, Pos.BASELINE_LEFT,30,400);
		button_delete.setOnAction((event) -> {
			dict.delete(combo1, area1);
		});
		
		setupButtonUI(button_save, "Symbol", 15, BUTTON_WIDTH, Pos.BASELINE_LEFT,180,400);
		button_save.setOnAction((event) -> {
			area2.setDisable(false);
			dict.save(area1, text1);
		});
		
		setupButtonUI(button_debug, "Symbol", 15, BUTTON_WIDTH, Pos.BASELINE_LEFT,400,400);
		button_debug.setOnAction((event) -> {
			debug();
		});
		
		setupButtonUI(button_list, "Symbol", 15, BUTTON_WIDTH, Pos.BASELINE_LEFT,550,400);
		button_list.setOnAction((event) -> { });
		
		setupTextAreaUI(area1, "Arial", 14, 300, 300, 20, 150, true);
		
		setupTextAreaUI(area2, "Arial", 14, 300, 300, 340, 150, true);
		
		setupTextUI(text1, "Arial", 14, 250, Pos.BASELINE_LEFT, 30, 100, true);
		
		Scene resultScene = new Scene(theRoot, 700, 500);
		resultStage.setScene(resultScene);
		resultStage.show();
		theRoot.getChildren().addAll(button_Create, button_edit,button_run, button_debug,
				load, combo1, button_save,button_delete,button_list,area1, area2,text1,enter,select,programIn,programOut);
	
	return;
	}
	
	private void debug() {
	String a = area1.getText();
	Scanner b = new Scanner(a);
	while (b.hasNextLine()) {
		String c = b.nextLine();
		if (c.startsWith("*") || c.startsWith("/") || c.startsWith(".") || c.endsWith("+") || c.endsWith("-") || c.endsWith("*") || c.endsWith("/") || c.endsWith(".")) {
			area2.setText("*** Error: Write proper program");
		}
	}
	b.close();
		
	}

	/**********
	 * Private local method to initialize the standard fields for a text field
	 */
	private void setupTextUI(TextField t, String ff, double f, double w, Pos p, double x, double y, boolean e) {
		t.setFont(Font.font(ff, f));
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y);
		t.setEditable(e);
	}
	
	/**********
	 * Private local method to initialize the standard fields for a button
	 */
	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y){
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);		
	}
	
	/**********
	 * Private local method to initialize the standard fields for a text area
	 */
	private void setupTextAreaUI(TextArea a, String ff, double f, double w, double h, double x, double y, boolean e){
		a.setFont(Font.font(ff, f));
		a.setMaxWidth(w);
		a.setMaxHeight(h);
		a.setLayoutX(x);
		a.setLayoutY(y);		
		a.setEditable(e);
	}
	
	/**********
	 * Private local method to initialize the standard fields for a label
	 */
	
	private void setupComboBoxUI(@SuppressWarnings("rawtypes") ComboBox c, double w, double h, double x, double y){
		c.setLayoutX(x);
		c.setLayoutY(y);
		c.setMinWidth(w);
		c.setMinHeight(h);		
	}
	
	private void setupLabelUI(Label a, double x, double y) {
		a.setLayoutX(x);
		a.setLayoutY(y);
	}
	
	/**********************************************************************************************
	 * 
	 * The ExpressionTreeBuilderEvaluator Class provides the functions that parses an input stream
	 * of lexical tokens, uses the structure to build an expression tree, and then uses that tree
	 * to compute the value of the expression.
	 * 
	 * The following are the primary followed by the secondary attributes for this Class
	 */

	
	/**********
	 * The addSub Expression method parses a sequence of expression elements that are added
	 * together, subtracted from one another, or a blend of them.
	 * 
	 * @return	The method returns a boolean value indicating if the parse was successful
	 */
	private static boolean addSubExpr() {

		// The method assumes the input is a sequence of additive/subtractive elements separated
		// by addition and/or subtraction operators
		if (mpyDivExpr()) {
			
			// Once an additive/subtractive element has been found, it can be followed by a
			// sequence of addition or subtraction operators followed by another 
			// additive/subtractive element.  Therefore we start by looking for a "+" or a "-"
			while ((current.getTokenKind() == Kind.SYMBOL) && 
					((current.getTokenCode() == 6) ||		// The "+" operator
					 (current.getTokenCode() == 7))) {		// The "-" operator
				
				// When you find a "+" or a "-", push it onto the operator stack
				opStack.push(current);
				
				// Advance to the next input token
				current = next;
				next = lexer.accept();
				
				// Look for the next additive/subtractive element
				if (mpyDivExpr()) {
					
					// If one is found, pop the two operands and the operator
					ExprNode expr2 = exprStack.pop();
					ExprNode expr1 = exprStack.pop();
					Token oper = opStack.pop();
					
					// Create an Expression Tree node from those three items and push it onto
					// the expression stack
					exprStack.push(new ExprNode(oper, true, expr1, expr2));
				}
				else {
					
					// If we get here, we saw a "+" or a "-", but it was not followed by a valid
					// additive/subtractive element
					System.out.println("Parse error: A required additive/subtractive element was not found");
					return false;
				}
			}
			
			// Reaching this point indicates that we have processed the sequence of 
			// additive/subtractive elements
			return true;
		}
		else
			
			// This indicates that the first thing found was not an additive/subtractive element
			return false;
	}
	
	/**********
	 * The mpyDiv Expression method parses a sequence of expression elements that are multiplied
	 * together, divided from one another, or a blend of them.
	 * 
	 * @return	The method returns a boolean value indicating if the parse was successful
	 */
	private static boolean mpyDivExpr() {

		// The method assumes the input is a sequence of terms separated by multiplication and/or 
		// division operators
		if (Parenthesis()) {
			
			// Once an multiplication/division element has been found, it can be followed by a
			// sequence of multiplication or division operators followed by another 
			// multiplication/division element.  Therefore we start by looking for a "*" or a "/"
			while ((current.getTokenKind() == Kind.SYMBOL) && 
					((current.getTokenCode() == 8) ||		// The "*" operator	
					 (current.getTokenCode() == 9))) {		// The "/" operator
				
				// When you find a "*" or a "/", push it onto the operator stack
				opStack.push(current);
				
				// Advance to the next input token
				current = next;
				next = lexer.accept();
				
				// Look for the next multiplication/division element
				if (Parenthesis()) {
					
					// If one is found, pop the two operands and the operator
					ExprNode expr2 = exprStack.pop();
					ExprNode expr1 = exprStack.pop();
					Token oper = opStack.pop();
					
					// Create an Expression Tree node from those three items and push it onto
					// the expression stack
					exprStack.push(new ExprNode(oper, true, expr1, expr2));
				}
				else {
					
					// If we get here, we saw a "*" or a "/", but it was not followed by a valid
					// multiplication/division element
					System.out.println("Parse error: a term was not found");
					return false;
				}
			}
			
			// Reaching this point indicates that we have processed the sequence of 
			// additive/subtractive elements
			return true;
		}
		else
			
			// This indicates that the first thing found was not a multiplication/division element
			return false;
	}
	
	private static boolean Parenthesis() {

		// The method assumes the input is a sequence of parenthesis elements separated
		// by "(" and/or ")" operators
		if (term()) {
			
			// Once an parenthesis element has been found, it can be followed by a
			// sequence of parenthesis operators followed by another 
			// parenthesis element.  Therefore we start by looking for a "(" or a ")"
			while ((current.getTokenKind() == Kind.SYMBOL) && 
					((current.getTokenCode() == 4) ||		// The "(" operator
					 (current.getTokenCode() == 5))) {		// The ")" operator
				
				// When you find a "(" or a ")", push it onto the operator stack
				opStack.push(current);
				
				// Advance to the next input token
				current = next;
				next = lexer.accept();
				
				// Look for the next parenthesis
				if (term()) {
					// If one is found, pop the two operands and the operator
					ExprNode expr2 = exprStack.pop();
					ExprNode expr1 = exprStack.pop();
					Token oper = opStack.pop();
					
					// Create an Expression Tree node from those three items and push it onto
					// the expression stack
					exprStack.push(new ExprNode(oper, true, expr1, expr2));
				}
				else {
					// If we get here, we saw a "(" or a ")", but it was not followed by a valid
					// parenthesis element
					System.out.println("Parse error: Required parenthesis was not found");
					return false;
				}
			}
			
			// Reaching this point indicates that we have processed the sequence of 
			// parenthesis elements
			return true;
		}
		else
			
			// This indicates that the first thing found was not an parenthesis element
			return false;
	}
	/**********
	 * The term Expression method parses constants.
	 * 
	 * @return	The method returns a boolean value indicating if the parse was successful
	 */
	private static boolean term() {
		
		// Parse the term
		if (current.getTokenKind() == Kind.FLOAT || 
			current.getTokenKind() == Kind.INTEGER) {
			
			// When you find one, push a corresponding expression tree node onto the stack
			exprStack.push(new ExprNode(current, false, null, null));
			
			// Advance to the next input token
			current = next;
			next = lexer.accept();
			
			// Signal that the term was found
			return true;
		}
		else
			
			// Signal that a term was not found
			return false;
	}
	
	/**********
	 * The compute method is passed a tree as an input parameter and computes the value of the
	 * tree based on the operator nodes and the value node in the tree.  Precedence is encoded
	 * into the tree structure, so there is no need to deal with it during the evaluation.
	 * 
	 * @param r - The input parameter of the expression tree
	 * 
	 * @return  - A double value of the result of evaluating the expression tree
	 */
	public static double compute(ExprNode r) {

		// Check to see if this expression tree node is an operator.
		if ((r.getOp().getTokenKind() == Kind.SYMBOL) && ((r.getOp().getTokenCode() == 6) ||
				(r.getOp().getTokenCode() == 7) || (r.getOp().getTokenCode() == 8) ||
				(r.getOp().getTokenCode() == 9))) {

			// if so, fetch the left and right sub-tree references and evaluate them
			double leftValue = compute(r.getLeft());
			double rightValue = compute(r.getRight());
			
			// Give the value for the left and the right sub-trees, use the operator code
			// to select the correct operation
			double result = 0;
			switch ((int)r.getOp().getTokenCode()) {
			case 6: result = leftValue + rightValue; break;
			case 7: result = leftValue - rightValue; break;
			case 8: result = leftValue * rightValue; break;
			case 9: result = leftValue / rightValue; break;
			}
			
			// Display the actual computation working from the leaves up to the root
			System.out.println("   " + result + " = " + leftValue + r.getOp().getTokenText() + rightValue);
			
			// Return the result to the caller
			return result;
		}
		
		// If the node is not an operator, determine what it is and fetch the value 
		else if (r.getOp().getTokenKind() == Kind.INTEGER) {
			Scanner convertInteger = new Scanner(r.getOp().getTokenText());
			Double result = convertInteger.nextDouble();
			convertInteger.close();
			return result;
		}
		else if (r.getOp().getTokenKind() == Kind.FLOAT) {
			Scanner convertFloat = new Scanner(r.getOp().getTokenText());
			Double result = convertFloat.nextDouble();
			convertFloat.close();
			return result;
		}
		
		// If it is not a recognized element, treat it as a value of zero
		else return 0.0;
	}

	/**********
	 * This is the mainline that drives the demonstration
	 */
	
	
	@SuppressWarnings("resource")
	public void Run() throws FileNotFoundException {

		area2.setEditable(true);

		if (!area1.getText().isEmpty() && !area1.getText().contains("print") && !area1.getText().contains("input")) {

			try {
				definitions();
			} catch (FileNotFoundException e) {

				e.printStackTrace();
			}

			theReader = new Scanner(area1.getText());
			// Show the source of the expression
			System.out.println();
			area2.appendText("The expression is: " + theExpression);
			System.out.println();

			// Set up the Scanner and the Lexer

			while (theReader.hasNextLine()) {

				String j = theReader.nextLine();
				Scanner t = new Scanner(j);

				lexer = new Lexer(t);
				current = lexer.accept();
				next = lexer.accept();

				// Invoke the parser and the tree builder
				boolean isValid = addSubExpr();
				area2.appendText("The expression is valid: " + isValid + "\n");
				if (isValid) {

					// Display the expression tree
					ExprNode theTree = exprStack.pop();
					String f = theTree.toString();

					area2.appendText(f);
					// Evaluate the expression tree
					area2.appendText("\nThe evaluation of the tree:");
					area2.appendText("\nThe resulting value is: " + compute(theTree));
				}
			}
		}

		else if ((area1.getText().contains("print") || area1.getText().contains("input")
				|| area1.getText().contains("=")) && (area2.getText().isEmpty() || !area2.getText().isEmpty())) {

			area2.clear();
			area2.setEditable(true);
			Scanner scan = new Scanner(area1.getText());

			while (scan.hasNextLine()) {

				String t = scan.nextLine();

				if (t.contains("print")) {

					Scanner scan1 = new Scanner(t);
					scan1.skip("print ");

					String j = scan1.nextLine();

					DefinitionsUserInterface b = new DefinitionsUserInterface();
					File name = b.getTextFieldData();

					if (!name.exists()) {
						area2.appendText(j + "\n");
					}

					else {

						StringTokenizer kl = new StringTokenizer(j);

						while (kl.hasMoreTokens()) {

							String k1 = kl.nextToken();

							Scanner scanner = new Scanner(name);
							while (scanner.hasNextLine()) {

								String[] tokens = scanner.nextLine().split(" ");

								if (k1.matches(tokens[0])) {

									j = j.replaceAll(k1, tokens[2]);

									area2.appendText(j + "\n");

								}

							}

						}

					}

				}

				else if (t.contains("input")) {
					area2.appendText("");

					area2.setOnKeyPressed((event) -> {

						if (event.getCode() == KeyCode.ENTER) {

							Scanner scan3 = new Scanner(area2.getText());
							Scanner scan5 = new Scanner(area1.getText());

							while (scan3.hasNextLine() && scan5.hasNextLine()) {

								String j = scan5.nextLine();

								String m = scan3.nextLine();

								if (m.matches("-?\\d+(\\.\\d+)?") && j.contains("input")) {

									Scanner scan8 = new Scanner(j);
									scan8.skip("input ");
									Scanner scan6 = new Scanner(m);
									String h = scan6.nextLine();
									String n = scan8.nextLine();

									File theDirectory = new File("Repository");
									if (!theDirectory.exists()) {
										theDirectory.mkdir();
										theDirectory.setReadable(true);
										theDirectory.setWritable(true);

									}

									DefinitionsUserInterface b = new DefinitionsUserInterface();
									File theDataFile = b.getTextFieldData();

									try (FileWriter writer = new FileWriter(theDataFile, true)) {

										writer.write("\n" + n + " " + "?" + " " + h + " " + "?" + " " + "?");

									} catch (IOException e) {
										e.printStackTrace();
									}

								}
							}
						}
					});

				}

				else {

					area2.setOnKeyPressed((event) -> {

						if (event.getCode() == KeyCode.ENTER) {

							Scanner scan3 = new Scanner(area2.getText());
							Scanner scan5 = new Scanner(area1.getText());

							while (scan3.hasNextLine() && scan5.hasNextLine()) {

								String j = scan5.nextLine();

								String m = scan3.nextLine();

								if (m.matches("-?\\d+(\\.\\d+)?") && j.contains("input")) {

									Scanner scan8 = new Scanner(j);
									scan8.skip("input ");
									Scanner scan6 = new Scanner(m);
									String h = scan6.nextLine();
									String n = scan8.nextLine();

									File theDirectory = new File("Repository");
									if (!theDirectory.exists()) {
										theDirectory.mkdir();
										theDirectory.setReadable(true);
										theDirectory.setWritable(true);

									}

									DefinitionsUserInterface b = new DefinitionsUserInterface();
									File theDataFile = b.getTextFieldData();

									try (FileWriter writer = new FileWriter(theDataFile, true)) {

										writer.write("\n" + n + " " + "?" + " " + h + " " + "?" + " " + "?");

									} catch (IOException e) {
										e.printStackTrace();
									}

								}

							}

							try {
								definitions();
							} catch (FileNotFoundException e) {

								e.printStackTrace();
							}

							Scanner scan11 = new Scanner(area2.getText());
							while (scan11.hasNextLine()) {

								String w = scan11.nextLine();
								if (w.contains("+") || w.contains("-") || w.contains("/") || w.contains("*")
										|| w.contains("(") || w.contains(")")) {
									Scanner scan12 = new Scanner(w);
									String e1 = scan12.nextLine();

									theReader = new Scanner(e1);
									// Show the source of the expression
									System.out.println();
									area2.appendText("The expression is: " + theExpression);
									System.out.println();

									// Set up the Scanner and the Lexer

									while (theReader.hasNextLine()) {

										String j = theReader.nextLine();
										Scanner t1 = new Scanner(j);

										lexer = new Lexer(t1);
										current = lexer.accept();
										next = lexer.accept();

										// Invoke the parser and the tree builder
										boolean isValid = addSubExpr();
										area2.appendText("The expression is valid: " + isValid + "\n");
										if (isValid) {

											// Display the expression tree
											ExprNode theTree = exprStack.pop();
											String f = theTree.toString();

											area2.appendText(f);
											// Evaluate the expression tree
											area2.appendText("\nThe evaluation of the tree:");
											area2.appendText("\nThe resulting value is: " + compute(theTree));
										}
										
									}
									
								}
								
							}

						}

					});

				}

			}

		}

	}

	@SuppressWarnings("resource")
	private void definitions() throws NoSuchElementException, FileNotFoundException {
		if (!area1.getText().isEmpty() && (area1.getText().contains("print") || area1.getText().contains("input"))) {
			String bb = area1.getText();

			DefinitionsUserInterface b = new DefinitionsUserInterface();
			File name = b.getTextFieldData();
			System.out.println(name.toString());
			Scanner scan13 = new Scanner(bb);
			while (scan13.hasNextLine()) {
				String k = scan13.nextLine();
				if (!k.contains("print") && !k.contains("input")) {

					Scanner scan14 = new Scanner(k);

					String ll = scan14.nextLine();

					StringTokenizer kl = new StringTokenizer(ll, "-?\\d+(\\.\\d+)?\n");

					while (kl.hasMoreTokens()) {

						String k1 = kl.nextToken();

						Scanner scanner = new Scanner(name);
						while (scanner.hasNextLine()) {

							String[] tokens = scanner.nextLine().split(" ");

							if (k1.matches(tokens[0])) {

								ll = ll.replaceAll(k1, tokens[2]);

							}

						}

					}
					area2.appendText(ll + "\n");

				}

			}

		}

		else {

			String bb = area1.getText();

			DefinitionsUserInterface b = new DefinitionsUserInterface();
			File name = b.getTextFieldData();
			Scanner scan14 = new Scanner(area1.getText());
			while (scan14.hasNextLine()) {

				String ty = scan14.nextLine();

				StringTokenizer kl = new StringTokenizer(ty, "-?\\d+(\\.\\d+)?\n");

				while (kl.hasMoreTokens()) {

					String k1 = kl.nextToken();

					Scanner scanner = new Scanner(name);
					while (scanner.hasNextLine()) {

						String[] tokens = scanner.nextLine().split(" ");

						if (k1.matches(tokens[0])) {

							bb = bb.replaceAll(k1, tokens[2]);

							area1.setText(bb);
						}

					}

				}

			}

		}

	}

	private void ShowFile() {
		List<String> a = new ArrayList<String>();
		for (File file : name) {
			if (file.isFile()) {
				a.add(file.getName());
			}
		}
		list.addAll(a);

	}

}
	